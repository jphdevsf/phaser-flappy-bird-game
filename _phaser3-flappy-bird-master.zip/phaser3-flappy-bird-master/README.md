# Learn to create a HTML5 Game in 5 Minutes

Build a flappy bird clone with `Phaser 3` and `TypeScript`.

You can access the tutorial [here](https://medium.com/@digit.sensitivee/learn-to-create-a-html5-game-in-5-minutes-604118f5d0ab).
